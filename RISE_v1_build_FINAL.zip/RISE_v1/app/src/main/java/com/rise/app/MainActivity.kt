package com.rise.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import android.content.Context

private val Paper = Color(0xFFF8F8F5)
private val Ink = Color(0xFF111111)
private val Lime = Color(0xFFB7F500)
private val Orange = Color(0xFFF08A24)
private val Green = Color(0xFF55A84F)
private val Blue = Color(0xFF4C8FE8)
private val Purple = Color(0xFF7A62D9)

data class Goal(val name: String, val unit: String, val target: Int, val value: Int, val color: Color, val icon: @Composable () -> Unit)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RiseApp(this) }
    }
}

@Composable
fun RiseApp(context: Context) {
    var tab by remember { mutableStateOf(0) }
    var calories by remember { mutableIntStateOf(prefs(context).getInt("cal", 0)) }
    var protein by remember { mutableIntStateOf(prefs(context).getInt("protein", 0)) }
    var water by remember { mutableIntStateOf(prefs(context).getInt("water", 0)) }
    var steps by remember { mutableIntStateOf(prefs(context).getInt("steps", 0)) }
    var showCalc by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = lightColorScheme(background = Paper, surface = Color.White, primary = Ink)) {
        Scaffold(
            containerColor = Paper,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Home","Food","Workout","Progress","Profile").forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(
                                when(i) {
                                    0 -> Icons.Default.Home
                                    1 -> Icons.Default.Restaurant
                                    2 -> Icons.Default.FitnessCenter
                                    3 -> Icons.Default.BarChart
                                    else -> Icons.Default.Person
                                }, label) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when(tab) {
                    0 -> HomeScreen(calories, protein, water, steps,
                        onCal = { calories = it; save(context,"cal",it) },
                        onProtein = { protein = it; save(context,"protein",it) },
                        onWater = { water = it; save(context,"water",it) },
                        onSteps = { steps = it; save(context,"steps",it) },
                        onCalculator = { showCalc = true })
                    1 -> FoodScreen()
                    2 -> SimplePage("WORKOUT", "Train. Recover. Repeat.", Icons.Default.FitnessCenter)
                    3 -> ProgressScreen()
                    4 -> ProfileScreen()
                }
            }
        }
        if (showCalc) CalculatorDialog { showCalc = false }
    }
}

private fun prefs(c: Context) = c.getSharedPreferences("rise_data", Context.MODE_PRIVATE)
private fun save(c: Context, key: String, value: Int) { prefs(c).edit().putInt(key, value).apply() }

@Composable
fun HomeScreen(cal: Int, protein: Int, water: Int, steps: Int,
               onCal:(Int)->Unit, onProtein:(Int)->Unit, onWater:(Int)->Unit, onSteps:(Int)->Unit,
               onCalculator:()->Unit) {
    val goals = listOf(
        Goal("Calories","kcal",2415,cal,Orange){ Icon(Icons.Default.LocalFireDepartment,null,Modifier.size(30.dp),tint=Orange) },
        Goal("Protein","g",174,protein,Green){ Icon(Icons.Default.FitnessCenter,null,Modifier.size(30.dp),tint=Green) },
        Goal("Water","ml",3395,water,Blue){ Icon(Icons.Default.WaterDrop,null,Modifier.size(30.dp),tint=Blue) },
        Goal("Steps","",10000,steps,Purple){ Icon(Icons.Default.DirectionsWalk,null,Modifier.size(30.dp),tint=Purple) }
    )
    LazyColumn(Modifier.fillMaxSize().padding(horizontal=22.dp), contentPadding=PaddingValues(top=28.dp,bottom=20.dp)) {
        item {
            Text("TODAY", color=Green, fontWeight=FontWeight.Bold, fontSize=15.sp)
            Text("Keep going. 💪", fontSize=34.sp, fontWeight=FontWeight.ExtraBold, color=Ink)
            Text("One good choice at a time.", color=Color.Gray, fontSize=17.sp)
            Spacer(Modifier.height(22.dp))
        }
        items(goals.size) { idx ->
            val g = goals[idx]
            GoalCard(g, onAdd = {
                when(idx) {
                    0 -> onCal((cal + 100).coerceAtMost(g.target))
                    1 -> onProtein((protein + 10).coerceAtMost(g.target))
                    2 -> onWater((water + 250).coerceAtMost(g.target))
                    3 -> onSteps((steps + 1000).coerceAtMost(g.target))
                }
            })
            Spacer(Modifier.height(12.dp))
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick=onCalculator, modifier=Modifier.weight(1f)) { Text("Calculator") }
                Button(onClick={}) { Text("Meal +") }
            }
            Spacer(Modifier.height(10.dp))
            Text("Quick water", fontWeight=FontWeight.Bold, fontSize=20.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                listOf(250,500,750,1000).forEach { n ->
                    OutlinedButton(onClick={onWater((water+n).coerceAtMost(3395))}, modifier=Modifier.weight(1f)) { Text("$n") }
                }
            }
        }
    }
}

@Composable
fun GoalCard(g: Goal, onAdd:()->Unit) {
    val left = (g.target-g.value).coerceAtLeast(0)
    val progress = (g.value.toFloat()/g.target).coerceIn(0f,1f)
    Card(shape=RoundedCornerShape(22.dp), colors=CardDefaults.cardColors(containerColor=Color.White),
        elevation=CardDefaults.cardElevation(1.dp), modifier=Modifier.fillMaxWidth()) {
        Row(Modifier.padding(18.dp), verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.size(68.dp).background(Paper,CircleShape), contentAlignment=Alignment.Center) { g.icon() }
            Spacer(Modifier.width(18.dp))
            Column(Modifier.weight(1f)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                    Text(g.name, fontSize=21.sp, fontWeight=FontWeight.Bold, color=Ink)
                    Text("$left ${g.unit} left", color=g.color, fontWeight=FontWeight.Bold)
                }
                Spacer(Modifier.height(9.dp))
                LinearProgressIndicator(progress={progress}, modifier=Modifier.fillMaxWidth(), color=g.color, trackColor=Color(0xFFE8E8E8))
                Spacer(Modifier.height(7.dp))
                Text("${g.value} / ${g.target} ${g.unit}", color=Color.Gray)
            }
            Spacer(Modifier.width(8.dp))
            IconButton(onClick=onAdd) { Icon(Icons.Default.AddCircleOutline,"Add",tint=Ink) }
        }
    }
}

@Composable fun FoodScreen() = SimplePage("FOOD","Log meals and keep a photo with every meal.",Icons.Default.Restaurant)
@Composable fun ProgressScreen() = SimplePage("PROGRESS","Your streak, badges, daily reports and progress gallery.",Icons.Default.BarChart)

@Composable
fun ProfileScreen() {
    LazyColumn(Modifier.fillMaxSize().padding(22.dp), contentPadding=PaddingValues(top=28.dp,bottom=24.dp)) {
        item {
            Text("PROFILE", fontSize=34.sp,fontWeight=FontWeight.ExtraBold)
            Text("Your RISE journey in one place.", color=Color.Gray,fontSize=17.sp)
            Spacer(Modifier.height(20.dp))
            Card(colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Text("Your journey",fontSize=22.sp,fontWeight=FontWeight.Bold)
                    Text("Photos • Videos • Daily reports • Badges",color=Color.Gray)
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                        listOf("📷\nPhotos","🎥\nVideos","📅\nReports","🏆\nBadges").forEach { x ->
                            OutlinedButton(onClick={},modifier=Modifier.weight(1f)) { Text(x, textAlign=androidx.compose.ui.text.style.TextAlign.Center) }
                        }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Card(colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Text("Daily reports",fontSize=22.sp,fontWeight=FontWeight.Bold)
                    Text("Your saved day-by-day summaries will appear here.",color=Color.Gray)
                }
            }
            Spacer(Modifier.height(14.dp))
            Card(colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Text("Badges earned",fontSize=22.sp,fontWeight=FontWeight.Bold)
                    Text("🔥 Consistency starter\n💪 First workout\n💧 Hydration starter\n🏅 First week complete",fontSize=17.sp,lineHeight=30.sp)
                }
            }
        }
    }
}

@Composable
fun SimplePage(title:String, subtitle:String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.Top) {
        Icon(icon,null,Modifier.size(34.dp),tint=Ink)
        Spacer(Modifier.height(12.dp))
        Text(title,fontSize=34.sp,fontWeight=FontWeight.ExtraBold)
        Text(subtitle,color=Color.Gray,fontSize=17.sp)
        Spacer(Modifier.height(25.dp))
        Card(colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text("Coming next",fontSize=22.sp,fontWeight=FontWeight.Bold)
                Text("We're building this section into the full RISE experience.",color=Color.Gray)
            }
        }
    }
}

@Composable
fun CalculatorDialog(onClose:()->Unit) {
    var value by remember { mutableStateOf("") }
    Dialog(onDismissRequest=onClose) {
        Surface(shape=RoundedCornerShape(24.dp),color=Color.White) {
            Column(Modifier.padding(20.dp).widthIn(min=280.dp)) {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                    Text("Calculator",fontSize=24.sp,fontWeight=FontWeight.Bold)
                    IconButton(onClick=onClose){Icon(Icons.Default.Close,"Close")}
                }
                Text(if(value.isEmpty()) "0" else value,Modifier.fillMaxWidth().padding(vertical=18.dp),fontSize=32.sp)
                val keys=listOf("7","8","9","÷","4","5","6","×","1","2","3","−","C","0","=","+")
                keys.forEachIndexed { i,k ->
                    if(i%4==0) Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {}
                }
                Column {
                    keys.chunked(4).forEach { row ->
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            row.forEach { k ->
                                Button(onClick={
                                    when(k) {
                                        "C" -> value=""
                                        "=" -> value = try { simpleEval(value).toString() } catch(_:Exception) { "Error" }
                                        else -> value += k
                                    }
                                },modifier=Modifier.weight(1f)){Text(k)}
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }
        }
    }
}

private fun simpleEval(s:String): Double {
    val clean=s.replace("×","*").replace("÷","/")
    val parts=Regex("(?<=[+\\-*/])|(?=[+\\-*/])").split(clean).filter{it.isNotBlank()}
    var result=parts.first().toDouble()
    var i=1
    while(i<parts.size){ val op=parts[i]; val n=parts[i+1].toDouble(); result=when(op){"+"->result+n;"-"->result-n;"*"->result*n;"/"->result/n;else->result}; i+=2 }
    return result
}
