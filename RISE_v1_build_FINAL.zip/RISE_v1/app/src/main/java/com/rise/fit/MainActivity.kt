package com.rise.fit

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max

private val Ink = Color(0xFF111111)
private val Paper = Color(0xFFF7F7F5)
private val Soft = Color(0xFFE9E9E7)
private val Muted = Color(0xFF666666)
private val Orange = Color(0xFFFF7A45)
private val Green = Color(0xFF6BBE45)
private val Blue = Color(0xFF4B8FE8)
private val Purple = Color(0xFF7C62D9)
private val Yellow = Color(0xFFE5B52B)

data class Targets(
    val calories: Int = 2400,
    val protein: Int = 170,
    val fiber: Int = 30,
    val water: Int = 3000,
    val steps: Int = 10000,
    val sleep: Int = 8
)

data class DayLog(
    val calories: Int = 0,
    val protein: Int = 0,
    val fiber: Int = 0,
    val water: Int = 0,
    val steps: Int = 0,
    val sleep: Int = 0
)

data class Meal(
    val name: String,
    val calories: Int,
    val protein: Int,
    val fiber: Int
)

class RiseStore(context: Context) {
    private val p = context.getSharedPreferences("rise_data", Context.MODE_PRIVATE)

    fun targets() = Targets(
        p.getInt("cal_target", 2400),
        p.getInt("protein_target", 170),
        p.getInt("fiber_target", 30),
        p.getInt("water_target", 3000),
        p.getInt("steps_target", 10000),
        p.getInt("sleep_target", 8)
    )

    fun saveTargets(t: Targets) {
        p.edit()
            .putInt("cal_target", t.calories)
            .putInt("protein_target", t.protein)
            .putInt("fiber_target", t.fiber)
            .putInt("water_target", t.water)
            .putInt("steps_target", t.steps)
            .putInt("sleep_target", t.sleep)
            .putBoolean("setup", true)
            .apply()
    }

    fun setupDone() = p.getBoolean("setup", false)

    fun log() = DayLog(
        p.getInt("cal", 0),
        p.getInt("protein", 0),
        p.getInt("fiber", 0),
        p.getInt("water", 0),
        p.getInt("steps", 0),
        p.getInt("sleep", 0)
    )

    fun saveLog(l: DayLog) {
        p.edit()
            .putInt("cal", l.calories)
            .putInt("protein", l.protein)
            .putInt("fiber", l.fiber)
            .putInt("water", l.water)
            .putInt("steps", l.steps)
            .putInt("sleep", l.sleep)
            .apply()
    }

    fun meals(): List<Meal> {
        val raw = p.getStringSet("meals", emptySet()) ?: emptySet()
        return raw.mapNotNull {
            val a = it.split("|")
            if (a.size == 4) Meal(a[0], a[1].toIntOrNull() ?: 0, a[2].toIntOrNull() ?: 0, a[3].toIntOrNull() ?: 0) else null
        }
    }

    fun saveMeals(list: List<Meal>) {
        p.edit().putStringSet("meals", list.map { "${it.name}|${it.calories}|${it.protein}|${it.fiber}" }.toSet()).apply()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = RiseStore(this)
        setContent { RiseApp(store) }
    }
}

@Composable
private fun RiseApp(store: RiseStore) {
    var setup by remember { mutableStateOf(!store.setupDone()) }
    var targets by remember { mutableStateOf(store.targets()) }
    var log by remember { mutableStateOf(store.log()) }
    var meals by remember { mutableStateOf(store.meals()) }
    var page by remember { mutableStateOf("Home") }

    MaterialTheme {
        if (setup) {
            SetupScreen {
                targets = it
                store.saveTargets(it)
                setup = false
            }
        } else {
            Scaffold(
                containerColor = Paper,
                bottomBar = { BottomBar(page) { page = it } }
            ) { pad ->
                Box(Modifier.fillMaxSize().padding(pad)) {
                    when (page) {
                        "Home" -> HomeScreen(targets, log) { amount ->
                            log = log.copy(water = log.water + amount)
                            store.saveLog(log)
                        }
                        "Food" -> FoodScreen(meals) { meal ->
                            meals = meals + meal
                            store.saveMeals(meals)
                            log = log.copy(
                                calories = log.calories + meal.calories,
                                protein = log.protein + meal.protein,
                                fiber = log.fiber + meal.fiber
                            )
                            store.saveLog(log)
                        }
                        "Workout" -> WorkoutScreen()
                        "Progress" -> ProgressScreen(log)
                        else -> MoreScreen(
                            log = log,
                            onSteps = { value ->
                                log = log.copy(steps = value)
                                store.saveLog(log)
                            },
                            onSleep = { value ->
                                log = log.copy(sleep = value)
                                store.saveLog(log)
                            },
                            onReset = {
                                log = DayLog()
                                meals = emptyList()
                                store.saveLog(log)
                                store.saveMeals(emptyList())
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SetupScreen(onDone: (Targets) -> Unit) {
    var calories by remember { mutableStateOf("2400") }
    var protein by remember { mutableStateOf("170") }
    var fiber by remember { mutableStateOf("30") }
    var water by remember { mutableStateOf("3000") }

    Surface(Modifier.fillMaxSize(), color = Paper) {
        LazyColumn(
            Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("RISE.", fontSize = 48.sp, fontWeight = FontWeight.Black)
                Text("Routine • Intake • Strength • Energy", color = Muted)
                Spacer(Modifier.height(12.dp))
                Text("Set your daily targets once.", fontSize = 24.sp, fontWeight = FontWeight.Black)
            }
            item { NumberField("Calories", calories) { calories = it } }
            item { NumberField("Protein (g)", protein) { protein = it } }
            item { NumberField("Fiber (g)", fiber) { fiber = it } }
            item { NumberField("Water (ml)", water) { water = it } }
            item {
                BigButton("START RISE", Green) {
                    onDone(
                        Targets(
                            calories.toIntOrNull() ?: 2400,
                            protein.toIntOrNull() ?: 170,
                            fiber.toIntOrNull() ?: 30,
                            water.toIntOrNull() ?: 3000
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(t: Targets, l: DayLog, addWater: (Int) -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Spacer(Modifier.height(12.dp))
            Text("TODAY", color = Green, fontWeight = FontWeight.Black)
            Text("Keep going. 💪", fontSize = 36.sp, fontWeight = FontWeight.Black)
            Text("One good choice at a time.", color = Muted, fontSize = 17.sp)
            Spacer(Modifier.height(8.dp))
        }
        item { MetricCard("Calories", "🔥", l.calories, t.calories, "kcal", Orange) }
        item { MetricCard("Protein", "💪", l.protein, t.protein, "g", Green) }
        item { MetricCard("Fiber", "🌾", l.fiber, t.fiber, "g", Yellow) }
        item { MetricCard("Water", "💧", l.water, t.water, "ml", Blue) }
        item { MetricCard("Steps", "👟", l.steps, t.steps, "", Purple) }
        item { MetricCard("Sleep", "🌙", l.sleep, t.sleep, "hrs", Purple) }
        item {
            CardBlock(Blue) {
                Text("QUICK WATER", fontWeight = FontWeight.Black)
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(250, 500, 750, 1000).forEach { amount ->
                        SmallButton("💧 $amount", Blue) { addWater(amount) }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(20.dp)) }
    }
}

@Composable
private fun MetricCard(name: String, emoji: String, current: Int, target: Int, unit: String, accent: Color) {
    val progress = (current.toFloat() / max(1, target)).coerceIn(0f, 1f)
    CardBlock(accent) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(62.dp).border(2.dp, Ink),
                contentAlignment = Alignment.Center
            ) { Text(emoji, fontSize = 28.sp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(name, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    Text("${max(0, target-current)} $unit left", color = accent, fontWeight = FontWeight.Black)
                }
                LinearProgressIndicator(
                    progress = { progress },
                    Modifier.fillMaxWidth().height(7.dp),
                    color = accent,
                    trackColor = Soft
                )
                Text("$current / $target $unit", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun FoodScreen(meals: List<Meal>, addMeal: (Meal) -> Unit) {
    var name by remember { mutableStateOf("") }
    var cal by remember { mutableStateOf("") }
    var protein by remember { mutableStateOf("") }
    var fiber by remember { mutableStateOf("") }

    LazyColumn(
        Modifier.fillMaxSize().padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("FOOD", fontSize = 31.sp, fontWeight = FontWeight.Black)
            Text("Log what you eat. Your entries stay saved.", color = Muted)
        }
        item {
            CardBlock(Orange) {
                Text("ADD MEAL", fontWeight = FontWeight.Black)
                Text("📷 Take a meal photo every time you eat — photo gallery comes in the next build.", color = Muted)
                NumberField("Meal name", name, false) { name = it }
                NumberField("Calories", cal) { cal = it }
                NumberField("Protein (g)", protein) { protein = it }
                NumberField("Fiber (g)", fiber) { fiber = it }
                BigButton("SAVE MEAL", Orange) {
                    if (name.isNotBlank()) {
                        addMeal(Meal(name, cal.toIntOrNull() ?: 0, protein.toIntOrNull() ?: 0, fiber.toIntOrNull() ?: 0))
                        name = ""; cal = ""; protein = ""; fiber = ""
                    }
                }
            }
        }
        item { Text("TODAY'S MEALS", fontWeight = FontWeight.Black, fontSize = 20.sp) }
        items(meals) { meal ->
            CardBlock(Orange) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(meal.name, fontWeight = FontWeight.Black)
                    Text("${meal.calories} kcal", color = Orange, fontWeight = FontWeight.Black)
                }
                Text("${meal.protein}g protein • ${meal.fiber}g fiber", color = Muted)
            }
        }
    }
}

@Composable
private fun WorkoutScreen() {
    val days = listOf(
        "MON" to listOf("Bench Press", "Incline Press", "Cable Fly", "Triceps"),
        "TUE" to listOf("Lat Pulldown", "Row", "Biceps Curl", "Hammer Curl"),
        "WED" to listOf("Squat", "Leg Press", "Leg Curl", "Calves"),
        "THU" to listOf("REST / MOBILITY"),
        "FRI" to listOf("Overhead Press", "Lateral Raise", "Rear Delt", "Plank"),
        "SAT" to listOf("FULL BODY / SPORT"),
        "SUN" to listOf("REST")
    )
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("WORKOUT", fontSize = 31.sp, fontWeight = FontWeight.Black)
            Text("A simple weekly plan.", color = Muted)
        }
        items(days) { (day, list) ->
            CardBlock(Purple) {
                Text(day, color = Purple, fontWeight = FontWeight.Black)
                list.forEach { exercise ->
                    var checked by remember { mutableStateOf(false) }
                    Row(
                        Modifier.fillMaxWidth().clickable { checked = !checked }.padding(vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked, { checked = it })
                        Text(exercise, fontWeight = if (checked) FontWeight.Normal else FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun ProgressScreen(log: DayLog) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("PROGRESS", fontSize = 31.sp, fontWeight = FontWeight.Black)
            Text("Your journey, kept simple.", color = Muted)
        }
        item {
            CardBlock(Green) {
                Text("🏆 BADGES", fontWeight = FontWeight.Black)
                Text("🔥 Consistency starter")
                Text("💪 First workout")
                Text("💧 Hydration starter")
            }
        }
        item {
            CardBlock(Purple) {
                Text("📸 PHOTOS & VIDEOS", fontWeight = FontWeight.Black)
                Text("Daily progress photos and weekly videos will appear here.", color = Muted)
                BigButton("OPEN GALLERY", Purple) {}
            }
        }
        item {
            CardBlock(Blue) {
                Text("📊 TODAY", fontWeight = FontWeight.Black)
                Text("Calories ${log.calories} • Protein ${log.protein}g • Water ${log.water}ml")
                Text("Steps ${log.steps} • Sleep ${log.sleep} hrs", color = Muted)
            }
        }
    }
}

@Composable
private fun MoreScreen(
    log: DayLog,
    onSteps: (Int) -> Unit,
    onSleep: (Int) -> Unit,
    onReset: () -> Unit
) {
    var steps by remember(log.steps) { mutableStateOf(log.steps.toString()) }
    var sleep by remember(log.sleep) { mutableStateOf(log.sleep.toString()) }

    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("MORE", fontSize = 31.sp, fontWeight = FontWeight.Black)
            Text("Tools and settings.", color = Muted)
        }
        item {
            CardBlock(Purple) {
                Text("PROFILE", fontWeight = FontWeight.Black)
                Text("📸 Photos & videos")
                Text("📅 Day-by-day reports")
                Text("🏆 Badges earned")
                Text("😴 Sleep history")
                BigButton("VIEW PROFILE", Purple) {}
            }
        }
        item {
            CardBlock(Blue) {
                Text("DAILY INPUTS", fontWeight = FontWeight.Black)
                NumberField("Steps", steps) { steps = it }
                BigButton("SAVE STEPS", Blue) { onSteps(steps.toIntOrNull() ?: 0) }
                NumberField("Sleep (hours)", sleep) { sleep = it }
                BigButton("SAVE SLEEP", Purple) { onSleep(sleep.toIntOrNull() ?: 0) }
            }
        }
        item {
            CardBlock(Ink) {
                Text("CALCULATOR", color = Ink, fontWeight = FontWeight.Black)
                SimpleCalculator()
            }
        }
        item {
            CardBlock(Orange) {
                Text("RESET TODAY", fontWeight = FontWeight.Black)
                Text("Clears today's logged numbers. Your targets remain.", color = Muted)
                BigButton("RESET", Orange) { onReset() }
            }
        }
    }
}

@Composable
private fun SimpleCalculator() {
    var display by remember { mutableStateOf("0") }
    var stored by remember { mutableStateOf<Double?>(null) }
    var op by remember { mutableStateOf<String?>(null) }
    var fresh by remember { mutableStateOf(false) }

    fun press(key: String) {
        when (key) {
            "AC" -> { display = "0"; stored = null; op = null; fresh = false }
            "+", "−", "×", "÷" -> {
                stored = display.toDoubleOrNull()
                op = key
                fresh = true
            }
            "=" -> {
                val a = stored
                val b = display.toDoubleOrNull()
                if (a != null && b != null && op != null) {
                    val r = when (op) {
                        "+" -> a + b
                        "−" -> a - b
                        "×" -> a * b
                        "÷" -> if (b == 0.0) Double.NaN else a / b
                        else -> b
                    }
                    display = if (r.isFinite()) r.toString().trimEnd('0').trimEnd('.') else "Error"
                    stored = null; op = null; fresh = true
                }
            }
            "." -> if (!display.contains(".")) display += "."
            else -> {
                if (fresh || display == "Error") { display = key; fresh = false }
                else if (display == "0") display = key else display += key
            }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(display, Modifier.fillMaxWidth().border(2.dp, Ink).padding(12.dp), fontSize = 25.sp, fontWeight = FontWeight.Black)
        val keys = listOf("AC","÷","×","−","7","8","9","+","4","5","6","=","1","2","3",".","0")
        keys.chunked(4).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                row.forEach { key ->
                    Button(
                        onClick = { press(key) },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(4.dp)
                    ) { Text(key, fontWeight = FontWeight.Black) }
                }
            }
        }
    }
}

@Composable
private fun NumberField(label: String, value: String, numeric: Boolean = true, onValue: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValue,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        keyboardOptions = if (numeric) KeyboardOptions(keyboardType = KeyboardType.Number) else KeyboardOptions.Default,
        singleLine = true
    )
}

@Composable
private fun CardBlock(accent: Color, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier.fillMaxWidth().border(2.dp, Ink, RoundedCornerShape(18.dp))
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

@Composable
private fun BigButton(text: String, accent: Color, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(48.dp).border(2.dp, Ink, RoundedCornerShape(12.dp)),
        colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Ink),
        shape = RoundedCornerShape(12.dp)
    ) { Text(text, fontWeight = FontWeight.Black) }
}

@Composable
private fun SmallButton(text: String, accent: Color, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier.weight(1f),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = Ink),
        border = ButtonDefaults.outlinedButtonBorder
    ) { Text(text, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun BottomBar(current: String, onPage: (String) -> Unit) {
    NavigationBar(containerColor = Color.White) {
        listOf(
            "Home" to Icons.Default.Home,
            "Food" to Icons.Default.Restaurant,
            "Workout" to Icons.Default.FitnessCenter,
            "Progress" to Icons.Default.BarChart,
            "More" to Icons.Default.MoreHoriz
        ).forEach { (name, icon) ->
            NavigationBarItem(
                selected = current == name,
                onClick = { onPage(name) },
                icon = { Icon(icon, contentDescription = name) },
                label = { Text(name) }
            )
        }
    }
}
