# RISE

RISE — Routine • Intake • Strength • Energy

Fresh Android app project. This is a new app and does not modify the previous FitForge project.

V1 includes:
- Clean minimalist dashboard with restrained accent colours
- Persistent daily targets and logged data
- Calories, protein, fibre, water, steps and sleep
- Meal logging
- Workout checklist
- Progress / badges / photo-video section placeholder
- Simple calculator
- GitHub Actions APK build
